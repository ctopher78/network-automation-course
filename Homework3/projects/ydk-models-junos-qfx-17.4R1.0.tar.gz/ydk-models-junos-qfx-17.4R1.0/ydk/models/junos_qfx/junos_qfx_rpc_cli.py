""" junos_qfx_rpc_cli 

Junos RPC YANG module for cli command(s)

"""
from collections import OrderedDict

from ydk.types import Entity, EntityPath, Identity, Enum, YType, YLeaf, YLeafList, YList, LeafDataList, Bits, Empty, Decimal64
from ydk.filters import YFilter
from ydk.errors import YError, YModelError
from ydk.errors.error_handler import handle_type_error as _handle_type_error




class GetAuthorizationInformation(Entity):
    """
    Show authorization and authentication information
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_cli.GetAuthorizationInformation.Output>`
    
    

    """

    _prefix = 'cli'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetAuthorizationInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-authorization-information"
        self.yang_parent_name = "junos-qfx-rpc-cli"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.output = GetAuthorizationInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-cli:get-authorization-information"
        self._is_frozen = True


    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: authorization_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'cli'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetAuthorizationInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-authorization-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('authorization_information', (YLeaf(YType.str, 'authorization-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.authorization_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-cli:get-authorization-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetAuthorizationInformation.Output, ['output', 'authorization_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetAuthorizationInformation()
        return self._top_entity



class GetCurrentWorkingDirectory(Entity):
    """
    Show current working directory
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_cli.GetCurrentWorkingDirectory.Output>`
    
    

    """

    _prefix = 'cli'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetCurrentWorkingDirectory, self).__init__()
        self._top_entity = None

        self.yang_name = "get-current-working-directory"
        self.yang_parent_name = "junos-qfx-rpc-cli"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.output = GetCurrentWorkingDirectory.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-cli:get-current-working-directory"
        self._is_frozen = True


    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: cli
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'cli'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetCurrentWorkingDirectory.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-current-working-directory"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('cli', (YLeaf(YType.str, 'cli'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.cli = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-cli:get-current-working-directory/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetCurrentWorkingDirectory.Output, ['output', 'cli', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetCurrentWorkingDirectory()
        return self._top_entity



