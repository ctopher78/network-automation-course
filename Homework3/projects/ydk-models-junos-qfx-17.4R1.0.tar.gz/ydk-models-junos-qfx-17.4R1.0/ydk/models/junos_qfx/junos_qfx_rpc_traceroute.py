""" junos_qfx_rpc_traceroute 

Junos RPC YANG module for traceroute command(s)

"""
from collections import OrderedDict

from ydk.types import Entity, EntityPath, Identity, Enum, YType, YLeaf, YLeafList, YList, LeafDataList, Bits, Empty, Decimal64
from ydk.filters import YFilter
from ydk.errors import YError, YModelError
from ydk.errors.error_handler import handle_type_error as _handle_type_error




class Traceroute(Entity):
    """
    Trace route to remote host
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.Traceroute.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.Traceroute.Output>`
    
    

    """

    _prefix = 'traceroute'
    _revision = '2017-01-01'

    def __init__(self):
        super(Traceroute, self).__init__()
        self._top_entity = None

        self.yang_name = "traceroute"
        self.yang_parent_name = "junos-qfx-rpc-traceroute"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = Traceroute.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = Traceroute.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-traceroute:traceroute"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: gateway
        
        	Address of router gateway to route through
        	**type**\: str
        
        .. attribute:: ttl
        
        	IP maximum time\-to\-live value (or IPv6 maximum hop\-limit value)
        	**type**\: str
        
        .. attribute:: wait
        
        	Number of seconds to wait for response
        	**type**\: str
        
        	**units**\: seconds
        
        .. attribute:: no_resolve
        
        	Don't attempt to print addresses symbolically
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: source
        
        	Source address to use in outgoing traceroute packets
        	**type**\: str
        
        .. attribute:: tos
        
        	IP type\-of\-service field (IPv4)
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..255
        
        .. attribute:: as_number_lookup
        
        	Look up AS numbers for each hop
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: bypass_routing
        
        	Bypass routing table, use specified interface
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: inet
        
        	Force traceroute to IPv4 destination
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: inet6
        
        	Force traceroute to IPv6 destination
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: next_hop
        
        	Next\-hop address
        	**type**\: str
        
        .. attribute:: interface
        
        	Name of interface to use for outgoing traffic
        	**type**\: union of the below types:
        
        		**type**\: str
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        .. attribute:: routing_instance
        
        	Name of routing instance for traceroute attempt
        	**type**\: str
        
        .. attribute:: vpn_interface
        
        	VPN interface for traceroute attempt
        	**type**\: union of the below types:
        
        		**type**\: str
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        	**status**\: deprecated
        
        .. attribute:: propagate_ttl
        
        	Enable propagate\-ttl for locally sourced RE traffic
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: host
        
        	Hostname or address of remote host
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: port
        
        	Port for ssh connection (default is 22)
        	**type**\: union of the below types:
        
        		**type**\: int
        
        			**range:** 0..4294967295
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(Traceroute.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "traceroute"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('gateway', (YLeaf(YType.str, 'gateway'), ['str'])),
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str'])),
                ('wait', (YLeaf(YType.str, 'wait'), ['str'])),
                ('no_resolve', (YLeaf(YType.empty, 'no-resolve'), ['Empty'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('tos', (YLeaf(YType.str, 'tos'), ['str','int'])),
                ('as_number_lookup', (YLeaf(YType.empty, 'as-number-lookup'), ['Empty'])),
                ('bypass_routing', (YLeaf(YType.empty, 'bypass-routing'), ['Empty'])),
                ('inet', (YLeaf(YType.empty, 'inet'), ['Empty'])),
                ('inet6', (YLeaf(YType.empty, 'inet6'), ['Empty'])),
                ('next_hop', (YLeaf(YType.str, 'next-hop'), ['str'])),
                ('interface', (YLeaf(YType.str, 'interface'), ['str','str'])),
                ('routing_instance', (YLeaf(YType.str, 'routing-instance'), ['str'])),
                ('vpn_interface', (YLeaf(YType.str, 'vpn-interface'), ['str','str'])),
                ('propagate_ttl', (YLeaf(YType.empty, 'propagate-ttl'), ['Empty'])),
                ('host', (YLeaf(YType.str, 'host'), ['str'])),
                ('port', (YLeaf(YType.str, 'port'), ['int','str'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.gateway = None
            self.ttl = None
            self.wait = None
            self.no_resolve = None
            self.source = None
            self.tos = None
            self.as_number_lookup = None
            self.bypass_routing = None
            self.inet = None
            self.inet6 = None
            self.next_hop = None
            self.interface = None
            self.routing_instance = None
            self.vpn_interface = None
            self.propagate_ttl = None
            self.host = None
            self.port = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(Traceroute.Input, ['gateway', 'ttl', 'wait', 'no_resolve', 'source', 'tos', 'as_number_lookup', 'bypass_routing', 'inet', 'inet6', 'next_hop', 'interface', 'routing_instance', 'vpn_interface', 'propagate_ttl', 'host', 'port', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: traceroute_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(Traceroute.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "traceroute"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('traceroute_results', (YLeaf(YType.str, 'traceroute-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.traceroute_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(Traceroute.Output, ['output', 'traceroute_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = Traceroute()
        return self._top_entity



class RequestTracerouteOverlay(Entity):
    """
    Traceroute overlay path
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.RequestTracerouteOverlay.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.RequestTracerouteOverlay.Output>`
    
    

    """

    _prefix = 'traceroute'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestTracerouteOverlay, self).__init__()
        self._top_entity = None

        self.yang_name = "request-traceroute-overlay"
        self.yang_parent_name = "junos-qfx-rpc-traceroute"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestTracerouteOverlay.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestTracerouteOverlay.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-traceroute:request-traceroute-overlay"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: tunnel_type
        
        	Tunnel type
        	**type**\:  :py:class:`TunnelType <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.RequestTracerouteOverlay.Input.TunnelType>`
        
        	**default value**\: vxlan
        
        .. attribute:: vni
        
        	Value of the vni that identifies the overlay segment
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..16777215
        
        	**mandatory**\: True
        
        .. attribute:: tunnel_src
        
        	Source VTEP IP address
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: tunnel_dst
        
        	Remote VTEP IP address
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: mac
        
        	Validate MAC address
        	**type**\: str
        
        .. attribute:: ttl
        
        	TTL to use in the OAM packets
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        	**default value**\: 255
        
        .. attribute:: hash_input_interface
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        .. attribute:: hash_source_mac
        
        	
        	**type**\: str
        
        .. attribute:: hash_destination_mac
        
        	
        	**type**\: str
        
        .. attribute:: hash_protocol
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: hash_source_address
        
        	
        	**type**\: str
        
        .. attribute:: hash_destination_address
        
        	
        	**type**\: str
        
        .. attribute:: hash_source_port
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65535
        
        .. attribute:: hash_destination_port
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65535
        
        .. attribute:: hash_vlan
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..4094
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestTracerouteOverlay.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-traceroute-overlay"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('tunnel_type', (YLeaf(YType.enumeration, 'tunnel-type'), [('ydk.models.junos_qfx.junos_qfx_rpc_traceroute', 'RequestTracerouteOverlay', 'Input.TunnelType')])),
                ('vni', (YLeaf(YType.str, 'vni'), ['str','int'])),
                ('tunnel_src', (YLeaf(YType.str, 'tunnel-src'), ['str'])),
                ('tunnel_dst', (YLeaf(YType.str, 'tunnel-dst'), ['str'])),
                ('mac', (YLeaf(YType.str, 'mac'), ['str'])),
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str','int'])),
                ('hash_input_interface', (YLeaf(YType.str, 'hash-input-interface'), ['str','str'])),
                ('hash_source_mac', (YLeaf(YType.str, 'hash-source-mac'), ['str'])),
                ('hash_destination_mac', (YLeaf(YType.str, 'hash-destination-mac'), ['str'])),
                ('hash_protocol', (YLeaf(YType.str, 'hash-protocol'), ['str','int'])),
                ('hash_source_address', (YLeaf(YType.str, 'hash-source-address'), ['str'])),
                ('hash_destination_address', (YLeaf(YType.str, 'hash-destination-address'), ['str'])),
                ('hash_source_port', (YLeaf(YType.str, 'hash-source-port'), ['str','int'])),
                ('hash_destination_port', (YLeaf(YType.str, 'hash-destination-port'), ['str','int'])),
                ('hash_vlan', (YLeaf(YType.str, 'hash-vlan'), ['str','int'])),
            ])
            self.tunnel_type = None
            self.vni = None
            self.tunnel_src = None
            self.tunnel_dst = None
            self.mac = None
            self.ttl = None
            self.hash_input_interface = None
            self.hash_source_mac = None
            self.hash_destination_mac = None
            self.hash_protocol = None
            self.hash_source_address = None
            self.hash_destination_address = None
            self.hash_source_port = None
            self.hash_destination_port = None
            self.hash_vlan = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:request-traceroute-overlay/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestTracerouteOverlay.Input, ['tunnel_type', 'vni', 'tunnel_src', 'tunnel_dst', 'mac', 'ttl', 'hash_input_interface', 'hash_source_mac', 'hash_destination_mac', 'hash_protocol', 'hash_source_address', 'hash_destination_address', 'hash_source_port', 'hash_destination_port', 'hash_vlan'], name, value)

        class TunnelType(Enum):
            """
            TunnelType (Enum Class)

            Tunnel type

            .. data:: vxlan = 0

            	Vxlan tunnel-type

            """

            vxlan = Enum.YLeaf(0, "vxlan")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestTracerouteOverlay.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-traceroute-overlay"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
            ])
            self.output = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:request-traceroute-overlay/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestTracerouteOverlay.Output, ['output'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestTracerouteOverlay()
        return self._top_entity



class TracerouteMplsLdp(Entity):
    """
    Trace FEC paths
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsLdp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsLdp.Output>`
    
    

    """

    _prefix = 'traceroute'
    _revision = '2017-01-01'

    def __init__(self):
        super(TracerouteMplsLdp, self).__init__()
        self._top_entity = None

        self.yang_name = "traceroute-mpls-ldp"
        self.yang_parent_name = "junos-qfx-rpc-traceroute"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = TracerouteMplsLdp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = TracerouteMplsLdp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-ldp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        .. attribute:: fec
        
        	IP address and optional prefix length of FEC
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: retries
        
        	Number of times to resend probe
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..9
        
        .. attribute:: source
        
        	Source address to use when sending probes
        	**type**\: str
        
        .. attribute:: exp
        
        	Class\-of\-service to use when sending probes
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: no_resolve
        
        	Don't attempt to print addresses symbolically
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: routing_instance
        
        	Name of routing instance for traceroute attempt
        	**type**\: str
        
        .. attribute:: ttl
        
        	Maximum time\-to\-live value
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: wait
        
        	Number of seconds to wait before resending probe
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 5..15
        
        .. attribute:: paths
        
        	Maximum number of paths to traverse
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: update
        
        	Update database contents with traceroute results
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: fanout
        
        	Maximum number of nexthops to search per node
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..64
        
        .. attribute:: destination
        
        	Destination address to use when sending probes
        	**type**\: str
        
        .. attribute:: pipe_mode
        
        	Traces only the outermost FEC
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsLdp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "traceroute-mpls-ldp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('fec', (YLeaf(YType.str, 'fec'), ['str'])),
                ('retries', (YLeaf(YType.str, 'retries'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('no_resolve', (YLeaf(YType.empty, 'no-resolve'), ['Empty'])),
                ('routing_instance', (YLeaf(YType.str, 'routing-instance'), ['str'])),
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str','int'])),
                ('wait', (YLeaf(YType.str, 'wait'), ['str','int'])),
                ('paths', (YLeaf(YType.str, 'paths'), ['str','int'])),
                ('update', (YLeaf(YType.empty, 'update'), ['Empty'])),
                ('fanout', (YLeaf(YType.str, 'fanout'), ['str','int'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('pipe_mode', (YLeaf(YType.empty, 'pipe-mode'), ['Empty'])),
            ])
            self.logical_system = None
            self.fec = None
            self.retries = None
            self.source = None
            self.exp = None
            self.detail = None
            self.no_resolve = None
            self.routing_instance = None
            self.ttl = None
            self.wait = None
            self.paths = None
            self.update = None
            self.fanout = None
            self.destination = None
            self.pipe_mode = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-ldp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsLdp.Input, ['logical_system', 'fec', 'retries', 'source', 'exp', 'detail', 'no_resolve', 'routing_instance', 'ttl', 'wait', 'paths', 'update', 'fanout', 'destination', 'pipe_mode'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: tracelsp
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsLdp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "traceroute-mpls-ldp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('tracelsp', (YLeaf(YType.str, 'tracelsp'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.tracelsp = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-ldp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsLdp.Output, ['output', 'tracelsp', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = TracerouteMplsLdp()
        return self._top_entity



class TracerouteMplsBgp(Entity):
    """
    Trace FEC paths
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsBgp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsBgp.Output>`
    
    

    """

    _prefix = 'traceroute'
    _revision = '2017-01-01'

    def __init__(self):
        super(TracerouteMplsBgp, self).__init__()
        self._top_entity = None

        self.yang_name = "traceroute-mpls-bgp"
        self.yang_parent_name = "junos-qfx-rpc-traceroute"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = TracerouteMplsBgp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = TracerouteMplsBgp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-bgp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        .. attribute:: fec
        
        	IP address and optional prefix length of FEC
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: retries
        
        	Number of times to resend probe
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..9
        
        .. attribute:: source
        
        	Source address to use when sending probes
        	**type**\: str
        
        .. attribute:: exp
        
        	Class\-of\-service to use when sending probes
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: no_resolve
        
        	Don't attempt to print addresses symbolically
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: routing_instance
        
        	Name of routing instance for traceroute attempt
        	**type**\: str
        
        .. attribute:: ttl
        
        	Maximum time\-to\-live value
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: wait
        
        	Number of seconds to wait before resending probe
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 5..15
        
        .. attribute:: paths
        
        	Maximum number of paths to traverse
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: pipe_mode
        
        	Traces only the outermost FEC
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: fanout
        
        	Maximum number of nexthops to search per node
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..64
        
        .. attribute:: destination
        
        	Destination address to use when sending probes
        	**type**\: str
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsBgp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "traceroute-mpls-bgp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('fec', (YLeaf(YType.str, 'fec'), ['str'])),
                ('retries', (YLeaf(YType.str, 'retries'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('no_resolve', (YLeaf(YType.empty, 'no-resolve'), ['Empty'])),
                ('routing_instance', (YLeaf(YType.str, 'routing-instance'), ['str'])),
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str','int'])),
                ('wait', (YLeaf(YType.str, 'wait'), ['str','int'])),
                ('paths', (YLeaf(YType.str, 'paths'), ['str','int'])),
                ('pipe_mode', (YLeaf(YType.empty, 'pipe-mode'), ['Empty'])),
                ('fanout', (YLeaf(YType.str, 'fanout'), ['str','int'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
            ])
            self.logical_system = None
            self.fec = None
            self.retries = None
            self.source = None
            self.exp = None
            self.detail = None
            self.no_resolve = None
            self.routing_instance = None
            self.ttl = None
            self.wait = None
            self.paths = None
            self.pipe_mode = None
            self.fanout = None
            self.destination = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-bgp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsBgp.Input, ['logical_system', 'fec', 'retries', 'source', 'exp', 'detail', 'no_resolve', 'routing_instance', 'ttl', 'wait', 'paths', 'pipe_mode', 'fanout', 'destination'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: tracelsp
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsBgp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "traceroute-mpls-bgp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('tracelsp', (YLeaf(YType.str, 'tracelsp'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.tracelsp = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-bgp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsBgp.Output, ['output', 'tracelsp', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = TracerouteMplsBgp()
        return self._top_entity



class TracerouteMplsRsvp(Entity):
    """
    Trace RSVP\-signaled LSP paths
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsRsvp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsRsvp.Output>`
    
    

    """

    _prefix = 'traceroute'
    _revision = '2017-01-01'

    def __init__(self):
        super(TracerouteMplsRsvp, self).__init__()
        self._top_entity = None

        self.yang_name = "traceroute-mpls-rsvp"
        self.yang_parent_name = "junos-qfx-rpc-traceroute"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = TracerouteMplsRsvp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = TracerouteMplsRsvp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-rsvp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        .. attribute:: lsp_name
        
        	Name of LSP
        	**type**\: str
        
        	**length:** 1..64
        
        	**mandatory**\: True
        
        .. attribute:: egress
        
        	Request only a specific multipoint egress to respond
        	**type**\: str
        
        .. attribute:: multipoint
        
        	Probe multipoint LSP
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: ttl
        
        	Maximum time\-to\-live value
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: retries
        
        	Number of times to resend probe
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..9
        
        .. attribute:: source
        
        	Source address to use when sending probes
        	**type**\: str
        
        .. attribute:: exp
        
        	Class\-of\-service to use when sending probes
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: no_resolve
        
        	Don't attempt to print addresses symbolically
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: routing_instance
        
        	Name of routing instance for traceroute attempt
        	**type**\: str
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsRsvp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "traceroute-mpls-rsvp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('lsp_name', (YLeaf(YType.str, 'lsp-name'), ['str'])),
                ('egress', (YLeaf(YType.str, 'egress'), ['str'])),
                ('multipoint', (YLeaf(YType.empty, 'multipoint'), ['Empty'])),
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str','int'])),
                ('retries', (YLeaf(YType.str, 'retries'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('no_resolve', (YLeaf(YType.empty, 'no-resolve'), ['Empty'])),
                ('routing_instance', (YLeaf(YType.str, 'routing-instance'), ['str'])),
            ])
            self.logical_system = None
            self.lsp_name = None
            self.egress = None
            self.multipoint = None
            self.ttl = None
            self.retries = None
            self.source = None
            self.exp = None
            self.detail = None
            self.no_resolve = None
            self.routing_instance = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-rsvp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsRsvp.Input, ['logical_system', 'lsp_name', 'egress', 'multipoint', 'ttl', 'retries', 'source', 'exp', 'detail', 'no_resolve', 'routing_instance'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: tracelsp
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsRsvp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "traceroute-mpls-rsvp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('tracelsp', (YLeaf(YType.str, 'tracelsp'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.tracelsp = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-rsvp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsRsvp.Output, ['output', 'tracelsp', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = TracerouteMplsRsvp()
        return self._top_entity



class TracerouteMplsL2vpn(Entity):
    """
    Trace L2vpn fec129
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsL2vpn.Output>`
    
    

    """

    _prefix = 'traceroute'
    _revision = '2017-01-01'

    def __init__(self):
        super(TracerouteMplsL2vpn, self).__init__()
        self._top_entity = None

        self.yang_name = "traceroute-mpls-l2vpn"
        self.yang_parent_name = "junos-qfx-rpc-traceroute"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.output = TracerouteMplsL2vpn.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-l2vpn"
        self._is_frozen = True


    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: tracepw
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsL2vpn.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "traceroute-mpls-l2vpn"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('tracepw', (YLeaf(YType.str, 'tracepw'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.tracepw = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-l2vpn/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsL2vpn.Output, ['output', 'tracepw', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = TracerouteMplsL2vpn()
        return self._top_entity



class TracerouteMplsMspw(Entity):
    """
    Trace the Layer 2 VPN connection
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsMspw.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.TracerouteMplsMspw.Output>`
    
    

    """

    _prefix = 'traceroute'
    _revision = '2017-01-01'

    def __init__(self):
        super(TracerouteMplsMspw, self).__init__()
        self._top_entity = None

        self.yang_name = "traceroute-mpls-mspw"
        self.yang_parent_name = "junos-qfx-rpc-traceroute"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = TracerouteMplsMspw.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = TracerouteMplsMspw.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-mspw"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        .. attribute:: interface
        
        	Name of l2vpn fec129 interface
        	**type**\: str
        
        	**length:** 1..64
        
        	**mandatory**\: True
        
        .. attribute:: ttl
        
        	Maximum time\-to\-live value
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: retries
        
        	Number of times to resend probe
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..9
        
        .. attribute:: source
        
        	Source address to use when sending probes
        	**type**\: str
        
        .. attribute:: exp
        
        	Class\-of\-service to use when sending probes
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: no_resolve
        
        	Don't attempt to print addresses symbolically
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsMspw.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "traceroute-mpls-mspw"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('interface', (YLeaf(YType.str, 'interface'), ['str'])),
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str','int'])),
                ('retries', (YLeaf(YType.str, 'retries'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('no_resolve', (YLeaf(YType.empty, 'no-resolve'), ['Empty'])),
            ])
            self.logical_system = None
            self.interface = None
            self.ttl = None
            self.retries = None
            self.source = None
            self.exp = None
            self.detail = None
            self.no_resolve = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-mspw/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsMspw.Input, ['logical_system', 'interface', 'ttl', 'retries', 'source', 'exp', 'detail', 'no_resolve'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: tracelsp
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(TracerouteMplsMspw.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "traceroute-mpls-mspw"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('tracelsp', (YLeaf(YType.str, 'tracelsp'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.tracelsp = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:traceroute-mpls-mspw/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(TracerouteMplsMspw.Output, ['output', 'tracelsp', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = TracerouteMplsMspw()
        return self._top_entity



class RequestTracerouteEthernet(Entity):
    """
    Trace route to an ethernet host by unicast mac address
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.RequestTracerouteEthernet.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.RequestTracerouteEthernet.Output>`
    
    

    """

    _prefix = 'traceroute'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestTracerouteEthernet, self).__init__()
        self._top_entity = None

        self.yang_name = "request-traceroute-ethernet"
        self.yang_parent_name = "junos-qfx-rpc-traceroute"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestTracerouteEthernet.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestTracerouteEthernet.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-traceroute:request-traceroute-ethernet"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: ttl
        
        	Maximum time\-to\-live value
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: wait
        
        	Number of seconds to wait for response
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        	**units**\: seconds
        
        .. attribute:: maintenance_domain
        
        	Name of maintenance domain
        	**type**\: str
        
        	**length:** 1..45
        
        	**mandatory**\: True
        
        .. attribute:: maintenance_association
        
        	Name of maintenance association
        	**type**\: str
        
        	**length:** 1..45
        
        	**mandatory**\: True
        
        .. attribute:: host
        
        	MAC address of remote host in xx\:xx\:xx\:xx\:xx\:xx format
        	**type**\: str
        
        .. attribute:: mep
        
        	MEP identifier of remote host (default 1)
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..8191
        
        .. attribute:: local_mep
        
        	MEP identifier of local host
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..8191
        
        .. attribute:: priority
        
        	Frame priority (802.1p) value
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: verbosity
        
        	
        	**type**\:  :py:class:`Verbosity <ydk.models.junos_qfx.junos_qfx_rpc_traceroute.RequestTracerouteEthernet.Input.Verbosity>`
        
        	**default value**\: brief
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestTracerouteEthernet.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-traceroute-ethernet"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str','int'])),
                ('wait', (YLeaf(YType.str, 'wait'), ['str','int'])),
                ('maintenance_domain', (YLeaf(YType.str, 'maintenance-domain'), ['str'])),
                ('maintenance_association', (YLeaf(YType.str, 'maintenance-association'), ['str'])),
                ('host', (YLeaf(YType.str, 'host'), ['str'])),
                ('mep', (YLeaf(YType.str, 'mep'), ['str','int'])),
                ('local_mep', (YLeaf(YType.str, 'local-mep'), ['str','int'])),
                ('priority', (YLeaf(YType.str, 'priority'), ['str','int'])),
                ('verbosity', (YLeaf(YType.enumeration, 'verbosity'), [('ydk.models.junos_qfx.junos_qfx_rpc_traceroute', 'RequestTracerouteEthernet', 'Input.Verbosity')])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.ttl = None
            self.wait = None
            self.maintenance_domain = None
            self.maintenance_association = None
            self.host = None
            self.mep = None
            self.local_mep = None
            self.priority = None
            self.verbosity = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:request-traceroute-ethernet/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestTracerouteEthernet.Input, ['ttl', 'wait', 'maintenance_domain', 'maintenance_association', 'host', 'mep', 'local_mep', 'priority', 'verbosity', 'logical_system'], name, value)

        class Verbosity(Enum):
            """
            Verbosity (Enum Class)

            .. data:: brief = 0

            	Display brief output

            .. data:: detail = 1

            	Display detail output

            """

            brief = Enum.YLeaf(0, "brief")

            detail = Enum.YLeaf(1, "detail")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: ethtraceroute_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'traceroute'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestTracerouteEthernet.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-traceroute-ethernet"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('ethtraceroute_results', (YLeaf(YType.str, 'ethtraceroute-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.ethtraceroute_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-traceroute:request-traceroute-ethernet/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestTracerouteEthernet.Output, ['output', 'ethtraceroute_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestTracerouteEthernet()
        return self._top_entity



