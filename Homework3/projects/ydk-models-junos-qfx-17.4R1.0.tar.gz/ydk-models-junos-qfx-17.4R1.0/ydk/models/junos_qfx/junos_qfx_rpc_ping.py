""" junos_qfx_rpc_ping 

Junos RPC YANG module for ping command(s)

"""
from collections import OrderedDict

from ydk.types import Entity, EntityPath, Identity, Enum, YType, YLeaf, YLeafList, YList, LeafDataList, Bits, Empty, Decimal64
from ydk.filters import YFilter
from ydk.errors import YError, YModelError
from ydk.errors.error_handler import handle_type_error as _handle_type_error




class Ping(Entity):
    """
    Ping remote target
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.Ping.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.Ping.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(Ping, self).__init__()
        self._top_entity = None

        self.yang_name = "ping"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = Ping.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = Ping.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:ping"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..2000000000
        
        	**units**\: packets
        
        .. attribute:: wait
        
        	Maximum wait time after sending final packet
        	**type**\: union of the below types:
        
        		**type**\: int
        
        			**range:** 0..4294967295
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        	**units**\: seconds
        
        .. attribute:: no_resolve
        
        	Don't attempt to print addresses symbolically
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: rapid
        
        	Send requests rapidly (default count of 5)
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: record_route
        
        	Record and report packet's path (IPv4)
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: brief
        
        	
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        	**status**\: deprecated
        
        .. attribute:: detail
        
        	Display incoming interface of received packet
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: do_not_fragment
        
        	Don't fragment echo request packets (IPv4)
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: loose_source
        
        	Intermediate loose source route entry (IPv4)
        	**type**\: list of str
        
        .. attribute:: interface
        
        	Source interface (multicast, all\-ones, unrouted packets)
        	**type**\: str
        
        .. attribute:: interval
        
        	Delay between ping requests
        	**type**\: str
        
        	**units**\: seconds
        
        .. attribute:: source
        
        	Source address of echo request
        	**type**\: str
        
        .. attribute:: pattern
        
        	Hexadecimal fill pattern
        	**type**\: str
        
        .. attribute:: size
        
        	Size of request packets
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..65468
        
        	**units**\: bytes
        
        .. attribute:: strict
        
        	Use strict source route option (IPv4)
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: strict_source
        
        	Intermediate strict source route entry (IPv4)
        	**type**\: list of str
        
        .. attribute:: ttl
        
        	IP time\-to\-live value (IPv6 hop\-limit value)
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        	**units**\: hops
        
        .. attribute:: verbose
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: tos
        
        	IP type\-of\-service value
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..255
        
        .. attribute:: bypass_routing
        
        	Bypass routing table, use specified interface
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: inet
        
        	Force ping to IPv4 destination
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: inet6
        
        	Force ping to IPv6 destination
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: routing_instance
        
        	Routing instance for ping attempt
        	**type**\: str
        
        .. attribute:: mac_address
        
        	MAC address of the nexthop in xx\:xx\:xx\:xx\:xx\:xx format
        	**type**\: str
        
        .. attribute:: host
        
        	Hostname or IP address of remote host
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(Ping.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "ping"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('wait', (YLeaf(YType.str, 'wait'), ['int','str'])),
                ('no_resolve', (YLeaf(YType.empty, 'no-resolve'), ['Empty'])),
                ('rapid', (YLeaf(YType.empty, 'rapid'), ['Empty'])),
                ('record_route', (YLeaf(YType.empty, 'record-route'), ['Empty'])),
                ('brief', (YLeaf(YType.empty, 'brief'), ['Empty'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('do_not_fragment', (YLeaf(YType.empty, 'do-not-fragment'), ['Empty'])),
                ('loose_source', (YLeafList(YType.str, 'loose-source'), ['str'])),
                ('interface', (YLeaf(YType.str, 'interface'), ['str'])),
                ('interval', (YLeaf(YType.str, 'interval'), ['str'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('pattern', (YLeaf(YType.str, 'pattern'), ['str'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('strict', (YLeaf(YType.empty, 'strict'), ['Empty'])),
                ('strict_source', (YLeafList(YType.str, 'strict-source'), ['str'])),
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str','int'])),
                ('verbose', (YLeaf(YType.empty, 'verbose'), ['Empty'])),
                ('tos', (YLeaf(YType.str, 'tos'), ['str','int'])),
                ('bypass_routing', (YLeaf(YType.empty, 'bypass-routing'), ['Empty'])),
                ('inet', (YLeaf(YType.empty, 'inet'), ['Empty'])),
                ('inet6', (YLeaf(YType.empty, 'inet6'), ['Empty'])),
                ('routing_instance', (YLeaf(YType.str, 'routing-instance'), ['str'])),
                ('mac_address', (YLeaf(YType.str, 'mac-address'), ['str'])),
                ('host', (YLeaf(YType.str, 'host'), ['str'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.count = None
            self.wait = None
            self.no_resolve = None
            self.rapid = None
            self.record_route = None
            self.brief = None
            self.detail = None
            self.do_not_fragment = None
            self.loose_source = []
            self.interface = None
            self.interval = None
            self.source = None
            self.pattern = None
            self.size = None
            self.strict = None
            self.strict_source = []
            self.ttl = None
            self.verbose = None
            self.tos = None
            self.bypass_routing = None
            self.inet = None
            self.inet6 = None
            self.routing_instance = None
            self.mac_address = None
            self.host = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:ping/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(Ping.Input, ['count', 'wait', 'no_resolve', 'rapid', 'record_route', 'brief', 'detail', 'do_not_fragment', 'loose_source', 'interface', 'interval', 'source', 'pattern', 'size', 'strict', 'strict_source', 'ttl', 'verbose', 'tos', 'bypass_routing', 'inet', 'inet6', 'routing_instance', 'mac_address', 'host', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: ping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(Ping.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "ping"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('ping_results', (YLeaf(YType.str, 'ping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.ping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:ping/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(Ping.Output, ['output', 'ping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = Ping()
        return self._top_entity



class RequestPingRsvpLsp(Entity):
    """
    Ping RSVP\-signaled LSP
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingRsvpLsp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingRsvpLsp.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingRsvpLsp, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-rsvp-lsp"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingRsvpLsp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingRsvpLsp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-lsp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: lsp_name
        
        	Name of LSP
        	**type**\: str
        
        	**length:** 1..64
        
        	**mandatory**\: True
        
        .. attribute:: standby
        
        	Name of standby path
        	**type**\: str
        
        .. attribute:: multipoint
        
        	Probe multipoint LSP
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: egress
        
        	Request only a specific multipoint egress to respond
        	**type**\: str
        
        .. attribute:: instance
        
        	Routing\-instance name
        	**type**\: str
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        .. attribute:: reply_mode
        
        	Reply mode for ping request
        	**type**\:  :py:class:`ReplyMode <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingRsvpLsp.Input.ReplyMode>`
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingRsvpLsp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-rsvp-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('lsp_name', (YLeaf(YType.str, 'lsp-name'), ['str'])),
                ('standby', (YLeaf(YType.str, 'standby'), ['str'])),
                ('multipoint', (YLeaf(YType.empty, 'multipoint'), ['Empty'])),
                ('egress', (YLeaf(YType.str, 'egress'), ['str'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('reply_mode', (YLeaf(YType.enumeration, 'reply-mode'), [('ydk.models.junos_qfx.junos_qfx_rpc_ping', 'RequestPingRsvpLsp', 'Input.ReplyMode')])),
            ])
            self.lsp_name = None
            self.standby = None
            self.multipoint = None
            self.egress = None
            self.instance = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self.reply_mode = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingRsvpLsp.Input, ['lsp_name', 'standby', 'multipoint', 'egress', 'instance', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system', 'reply_mode'], name, value)

        class ReplyMode(Enum):
            """
            ReplyMode (Enum Class)

            Reply mode for ping request

            .. data:: no_reply = 0

            	Do not reply

            .. data:: ip_udp = 1

            	Reply via an IPv4 or IPv6 UDP packet

            .. data:: application_level_control_channel = 2

            	Reply via application level control channel

            """

            no_reply = Enum.YLeaf(0, "no-reply")

            ip_udp = Enum.YLeaf(1, "ip-udp")

            application_level_control_channel = Enum.YLeaf(2, "application-level-control-channel")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingRsvpLsp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-rsvp-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingRsvpLsp.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingRsvpLsp()
        return self._top_entity



class RequestPingRsvpDynamicBypassLsp(Entity):
    """
    Dynamically created LSP, used for protecting other LSPs
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingRsvpDynamicBypassLsp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingRsvpDynamicBypassLsp.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingRsvpDynamicBypassLsp, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-rsvp-dynamic-bypass-lsp"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingRsvpDynamicBypassLsp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingRsvpDynamicBypassLsp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-dynamic-bypass-lsp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: lsp_name
        
        	Name of dynamic bypass LSP
        	**type**\: str
        
        	**length:** 1..64
        
        	**mandatory**\: True
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingRsvpDynamicBypassLsp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-rsvp-dynamic-bypass-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('lsp_name', (YLeaf(YType.str, 'lsp-name'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.lsp_name = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-dynamic-bypass-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingRsvpDynamicBypassLsp.Input, ['lsp_name', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingRsvpDynamicBypassLsp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-rsvp-dynamic-bypass-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-dynamic-bypass-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingRsvpDynamicBypassLsp.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingRsvpDynamicBypassLsp()
        return self._top_entity



class RequestPingRsvpManualBypassLsp(Entity):
    """
    Manually configured LSP, used for protecting other LSPs
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingRsvpManualBypassLsp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingRsvpManualBypassLsp.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingRsvpManualBypassLsp, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-rsvp-manual-bypass-lsp"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingRsvpManualBypassLsp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingRsvpManualBypassLsp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-manual-bypass-lsp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: lsp_name
        
        	Name of manual bypass LSP
        	**type**\: str
        
        	**length:** 1..64
        
        	**mandatory**\: True
        
        .. attribute:: interface
        
        	Name of the interface, which is protected by this bypass
        	**type**\: union of the below types:
        
        		**type**\: str
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        	**mandatory**\: True
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingRsvpManualBypassLsp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-rsvp-manual-bypass-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('lsp_name', (YLeaf(YType.str, 'lsp-name'), ['str'])),
                ('interface', (YLeaf(YType.str, 'interface'), ['str','str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.lsp_name = None
            self.interface = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-manual-bypass-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingRsvpManualBypassLsp.Input, ['lsp_name', 'interface', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingRsvpManualBypassLsp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-rsvp-manual-bypass-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-rsvp-manual-bypass-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingRsvpManualBypassLsp.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingRsvpManualBypassLsp()
        return self._top_entity



class RequestPingLdpLsp(Entity):
    """
    Ping LDP\-signaled LSP
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingLdpLsp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingLdpLsp.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingLdpLsp, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-ldp-lsp"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingLdpLsp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingLdpLsp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-ldp-lsp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: fec
        
        	IP prefix/length of forwarding equivalence class
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: instance
        
        	Routing\-instance name
        	**type**\: str
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingLdpLsp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-ldp-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('fec', (YLeaf(YType.str, 'fec'), ['str'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.fec = None
            self.instance = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-ldp-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingLdpLsp.Input, ['fec', 'instance', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingLdpLsp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-ldp-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-ldp-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingLdpLsp.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingLdpLsp()
        return self._top_entity



class RequestPingLdpP2mpLsp(Entity):
    """
    Ping LDP\-signaled P2MP LSP
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingLdpP2mpLsp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingLdpP2mpLsp.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingLdpP2mpLsp, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-ldp-p2mp-lsp"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingLdpP2mpLsp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingLdpP2mpLsp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-ldp-p2mp-lsp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: root_addr
        
        	IP address of p2mp lsp root
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: lsp_id
        
        	LSP ID of p2mp lsp
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..4294967295
        
        	**mandatory**\: True
        
        .. attribute:: egress
        
        	Request only a specific multipoint egress to respond
        	**type**\: str
        
        .. attribute:: instance
        
        	Routing\-instance name
        	**type**\: str
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingLdpP2mpLsp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-ldp-p2mp-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('root_addr', (YLeaf(YType.str, 'root-addr'), ['str'])),
                ('lsp_id', (YLeaf(YType.str, 'lsp-id'), ['str','int'])),
                ('egress', (YLeaf(YType.str, 'egress'), ['str'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.root_addr = None
            self.lsp_id = None
            self.egress = None
            self.instance = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-ldp-p2mp-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingLdpP2mpLsp.Input, ['root_addr', 'lsp_id', 'egress', 'instance', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingLdpP2mpLsp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-ldp-p2mp-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-ldp-p2mp-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingLdpP2mpLsp.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingLdpP2mpLsp()
        return self._top_entity



class RequestPingBgpLsp(Entity):
    """
    Ping BGP\-signaled LSP
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingBgpLsp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingBgpLsp.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingBgpLsp, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-bgp-lsp"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingBgpLsp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingBgpLsp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-bgp-lsp"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: fec
        
        	IP prefix/length of forwarding equivalence class
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: bottom_label_ttl
        
        	Time to live for the bottom label in the label stack
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: instance
        
        	Routing\-instance name
        	**type**\: str
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingBgpLsp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-bgp-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('fec', (YLeaf(YType.str, 'fec'), ['str'])),
                ('bottom_label_ttl', (YLeaf(YType.str, 'bottom-label-ttl'), ['str','int'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.fec = None
            self.bottom_label_ttl = None
            self.instance = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-bgp-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingBgpLsp.Input, ['fec', 'bottom_label_ttl', 'instance', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingBgpLsp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-bgp-lsp"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-bgp-lsp/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingBgpLsp.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingBgpLsp()
        return self._top_entity



class RequestPingL3vpn(Entity):
    """
    Ping LSP to Layer 3 VPN prefix
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL3vpn.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL3vpn.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingL3vpn, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-l3vpn"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingL3vpn.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingL3vpn.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-l3vpn"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: l3vpn_name
        
        	Name of Layer 3 VPN
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: prefix
        
        	IP prefix/length of Layer 3 VPN
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: bottom_label_ttl
        
        	Time to live for the bottom label in the label stack
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL3vpn.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-l3vpn"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('l3vpn_name', (YLeaf(YType.str, 'l3vpn-name'), ['str'])),
                ('prefix', (YLeaf(YType.str, 'prefix'), ['str'])),
                ('bottom_label_ttl', (YLeaf(YType.str, 'bottom-label-ttl'), ['str','int'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.l3vpn_name = None
            self.prefix = None
            self.bottom_label_ttl = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l3vpn/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL3vpn.Input, ['l3vpn_name', 'prefix', 'bottom_label_ttl', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL3vpn.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-l3vpn"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l3vpn/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL3vpn.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingL3vpn()
        return self._top_entity



class RequestPingL2vpnInterface(Entity):
    """
    Locate LSP using interface name
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnInterface.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnInterface.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingL2vpnInterface, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-l2vpn-interface"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingL2vpnInterface.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingL2vpnInterface.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-interface"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: interface_name
        
        	Interface name
        	**type**\: union of the below types:
        
        		**type**\: str
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        	**mandatory**\: True
        
        .. attribute:: bottom_label_ttl
        
        	Time to live for the bottom label in the label stack
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: reply_mode
        
        	Reply mode for ping request
        	**type**\:  :py:class:`ReplyMode <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnInterface.Input.ReplyMode>`
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2vpnInterface.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-l2vpn-interface"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('interface_name', (YLeaf(YType.str, 'interface-name'), ['str','str'])),
                ('bottom_label_ttl', (YLeaf(YType.str, 'bottom-label-ttl'), ['str','int'])),
                ('reply_mode', (YLeaf(YType.enumeration, 'reply-mode'), [('ydk.models.junos_qfx.junos_qfx_rpc_ping', 'RequestPingL2vpnInterface', 'Input.ReplyMode')])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.interface_name = None
            self.bottom_label_ttl = None
            self.reply_mode = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-interface/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2vpnInterface.Input, ['interface_name', 'bottom_label_ttl', 'reply_mode', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)

        class ReplyMode(Enum):
            """
            ReplyMode (Enum Class)

            Reply mode for ping request

            .. data:: no_reply = 0

            	Do not reply

            .. data:: ip_udp = 1

            	Reply via an IPv4 or IPv6 UDP packet

            .. data:: application_level_control_channel = 2

            	Reply via application level control channel

            """

            no_reply = Enum.YLeaf(0, "no-reply")

            ip_udp = Enum.YLeaf(1, "ip-udp")

            application_level_control_channel = Enum.YLeaf(2, "application-level-control-channel")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2vpnInterface.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-l2vpn-interface"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-interface/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2vpnInterface.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingL2vpnInterface()
        return self._top_entity



class RequestPingL2vpnInstance(Entity):
    """
    Instance to which this connection belongs
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnInstance.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnInstance.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingL2vpnInstance, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-l2vpn-instance"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingL2vpnInstance.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingL2vpnInstance.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-instance"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: instance_name
        
        	Layer 2 VPN name
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: local_site_id
        
        	Layer 2 VPN local site identifier
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65534
        
        	**mandatory**\: True
        
        .. attribute:: remote_site_id
        
        	Layer 2 VPN remote site identifier
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65534
        
        	**mandatory**\: True
        
        .. attribute:: bottom_label_ttl
        
        	Time to live for the bottom label in the label stack
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: reply_mode
        
        	Reply mode for ping request
        	**type**\:  :py:class:`ReplyMode <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnInstance.Input.ReplyMode>`
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2vpnInstance.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-l2vpn-instance"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('instance_name', (YLeaf(YType.str, 'instance-name'), ['str'])),
                ('local_site_id', (YLeaf(YType.str, 'local-site-id'), ['str','int'])),
                ('remote_site_id', (YLeaf(YType.str, 'remote-site-id'), ['str','int'])),
                ('bottom_label_ttl', (YLeaf(YType.str, 'bottom-label-ttl'), ['str','int'])),
                ('reply_mode', (YLeaf(YType.enumeration, 'reply-mode'), [('ydk.models.junos_qfx.junos_qfx_rpc_ping', 'RequestPingL2vpnInstance', 'Input.ReplyMode')])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.instance_name = None
            self.local_site_id = None
            self.remote_site_id = None
            self.bottom_label_ttl = None
            self.reply_mode = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-instance/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2vpnInstance.Input, ['instance_name', 'local_site_id', 'remote_site_id', 'bottom_label_ttl', 'reply_mode', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)

        class ReplyMode(Enum):
            """
            ReplyMode (Enum Class)

            Reply mode for ping request

            .. data:: no_reply = 0

            	Do not reply

            .. data:: ip_udp = 1

            	Reply via an IPv4 or IPv6 UDP packet

            .. data:: application_level_control_channel = 2

            	Reply via application level control channel

            """

            no_reply = Enum.YLeaf(0, "no-reply")

            ip_udp = Enum.YLeaf(1, "ip-udp")

            application_level_control_channel = Enum.YLeaf(2, "application-level-control-channel")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2vpnInstance.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-l2vpn-instance"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-instance/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2vpnInstance.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingL2vpnInstance()
        return self._top_entity



class RequestPingL2vpnFec129Interface(Entity):
    """
    Locate Pseudowire using interface name
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnFec129Interface.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnFec129Interface.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingL2vpnFec129Interface, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-l2vpn-fec129-interface"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingL2vpnFec129Interface.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingL2vpnFec129Interface.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-fec129-interface"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: interface_name
        
        	Interface name
        	**type**\: union of the below types:
        
        		**type**\: str
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        	**mandatory**\: True
        
        .. attribute:: bottom_label_ttl
        
        	Time to live for the bottom label in the label stack
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: reply_mode
        
        	Reply mode for ping request
        	**type**\:  :py:class:`ReplyMode <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnFec129Interface.Input.ReplyMode>`
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2vpnFec129Interface.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-l2vpn-fec129-interface"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('interface_name', (YLeaf(YType.str, 'interface-name'), ['str','str'])),
                ('bottom_label_ttl', (YLeaf(YType.str, 'bottom-label-ttl'), ['str','int'])),
                ('reply_mode', (YLeaf(YType.enumeration, 'reply-mode'), [('ydk.models.junos_qfx.junos_qfx_rpc_ping', 'RequestPingL2vpnFec129Interface', 'Input.ReplyMode')])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.interface_name = None
            self.bottom_label_ttl = None
            self.reply_mode = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-fec129-interface/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2vpnFec129Interface.Input, ['interface_name', 'bottom_label_ttl', 'reply_mode', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)

        class ReplyMode(Enum):
            """
            ReplyMode (Enum Class)

            Reply mode for ping request

            .. data:: no_reply = 0

            	Do not reply

            .. data:: ip_udp = 1

            	Reply via an IPv4 or IPv6 UDP packet

            .. data:: application_level_control_channel = 2

            	Reply via application level control channel

            """

            no_reply = Enum.YLeaf(0, "no-reply")

            ip_udp = Enum.YLeaf(1, "ip-udp")

            application_level_control_channel = Enum.YLeaf(2, "application-level-control-channel")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2vpnFec129Interface.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-l2vpn-fec129-interface"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-fec129-interface/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2vpnFec129Interface.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingL2vpnFec129Interface()
        return self._top_entity



class RequestPingL2vpnFec129Instance(Entity):
    """
    Instance to which this connection belongs
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnFec129Instance.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnFec129Instance.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingL2vpnFec129Instance, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-l2vpn-fec129-instance"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingL2vpnFec129Instance.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingL2vpnFec129Instance.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-fec129-instance"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: instance_name
        
        	Layer 2 VPN name
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: local_id
        
        	Layer 2 VPN Source Attachment Individual Identifier (SAII)
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: remote_id
        
        	Layer 2 VPN Target Attachment Individual Identifier (TAII)
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: remote_pe_address
        
        	Layer 2 Remote PE address
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: bottom_label_ttl
        
        	Time to live for the bottom label in the label stack
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: reply_mode
        
        	Reply mode for ping request
        	**type**\:  :py:class:`ReplyMode <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2vpnFec129Instance.Input.ReplyMode>`
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2vpnFec129Instance.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-l2vpn-fec129-instance"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('instance_name', (YLeaf(YType.str, 'instance-name'), ['str'])),
                ('local_id', (YLeaf(YType.str, 'local-id'), ['str'])),
                ('remote_id', (YLeaf(YType.str, 'remote-id'), ['str'])),
                ('remote_pe_address', (YLeaf(YType.str, 'remote-pe-address'), ['str'])),
                ('bottom_label_ttl', (YLeaf(YType.str, 'bottom-label-ttl'), ['str','int'])),
                ('reply_mode', (YLeaf(YType.enumeration, 'reply-mode'), [('ydk.models.junos_qfx.junos_qfx_rpc_ping', 'RequestPingL2vpnFec129Instance', 'Input.ReplyMode')])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.instance_name = None
            self.local_id = None
            self.remote_id = None
            self.remote_pe_address = None
            self.bottom_label_ttl = None
            self.reply_mode = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-fec129-instance/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2vpnFec129Instance.Input, ['instance_name', 'local_id', 'remote_id', 'remote_pe_address', 'bottom_label_ttl', 'reply_mode', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)

        class ReplyMode(Enum):
            """
            ReplyMode (Enum Class)

            Reply mode for ping request

            .. data:: no_reply = 0

            	Do not reply

            .. data:: ip_udp = 1

            	Reply via an IPv4 or IPv6 UDP packet

            .. data:: application_level_control_channel = 2

            	Reply via application level control channel

            """

            no_reply = Enum.YLeaf(0, "no-reply")

            ip_udp = Enum.YLeaf(1, "ip-udp")

            application_level_control_channel = Enum.YLeaf(2, "application-level-control-channel")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2vpnFec129Instance.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-l2vpn-fec129-instance"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2vpn-fec129-instance/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2vpnFec129Instance.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingL2vpnFec129Instance()
        return self._top_entity



class RequestPingL2circuitInterface(Entity):
    """
    Locate LSP from interface name
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2circuitInterface.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2circuitInterface.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingL2circuitInterface, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-l2circuit-interface"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingL2circuitInterface.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingL2circuitInterface.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-l2circuit-interface"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: v1
        
        	Ping using Layer 2 circuit TLV (type 9)
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: interface_name
        
        	Interface name
        	**type**\: union of the below types:
        
        		**type**\: str
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        	**mandatory**\: True
        
        .. attribute:: reply_mode
        
        	Reply mode for ping request
        	**type**\:  :py:class:`ReplyMode <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2circuitInterface.Input.ReplyMode>`
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2circuitInterface.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-l2circuit-interface"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('v1', (YLeaf(YType.empty, 'v1'), ['Empty'])),
                ('interface_name', (YLeaf(YType.str, 'interface-name'), ['str','str'])),
                ('reply_mode', (YLeaf(YType.enumeration, 'reply-mode'), [('ydk.models.junos_qfx.junos_qfx_rpc_ping', 'RequestPingL2circuitInterface', 'Input.ReplyMode')])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.v1 = None
            self.interface_name = None
            self.reply_mode = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2circuit-interface/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2circuitInterface.Input, ['v1', 'interface_name', 'reply_mode', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)

        class ReplyMode(Enum):
            """
            ReplyMode (Enum Class)

            Reply mode for ping request

            .. data:: no_reply = 0

            	Do not reply

            .. data:: ip_udp = 1

            	Reply via an IPv4 or IPv6 UDP packet

            .. data:: application_level_control_channel = 2

            	Reply via application level control channel

            """

            no_reply = Enum.YLeaf(0, "no-reply")

            ip_udp = Enum.YLeaf(1, "ip-udp")

            application_level_control_channel = Enum.YLeaf(2, "application-level-control-channel")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2circuitInterface.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-l2circuit-interface"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2circuit-interface/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2circuitInterface.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingL2circuitInterface()
        return self._top_entity



class RequestPingL2circuitVirtualCircuit(Entity):
    """
    Locate LSP from virtual circuit information
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2circuitVirtualCircuit.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2circuitVirtualCircuit.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingL2circuitVirtualCircuit, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-l2circuit-virtual-circuit"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingL2circuitVirtualCircuit.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingL2circuitVirtualCircuit.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-l2circuit-virtual-circuit"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: v1
        
        	Ping using Layer 2 circuit TLV (type 9)
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: neighbor
        
        	Address of remote neighbor
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: virtual_circuit_id
        
        	Layer 2 circuit identifier
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..4294967295
        
        	**mandatory**\: True
        
        .. attribute:: reply_mode
        
        	Reply mode for ping request
        	**type**\:  :py:class:`ReplyMode <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingL2circuitVirtualCircuit.Input.ReplyMode>`
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2circuitVirtualCircuit.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-l2circuit-virtual-circuit"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('v1', (YLeaf(YType.empty, 'v1'), ['Empty'])),
                ('neighbor', (YLeaf(YType.str, 'neighbor'), ['str'])),
                ('virtual_circuit_id', (YLeaf(YType.str, 'virtual-circuit-id'), ['str','int'])),
                ('reply_mode', (YLeaf(YType.enumeration, 'reply-mode'), [('ydk.models.junos_qfx.junos_qfx_rpc_ping', 'RequestPingL2circuitVirtualCircuit', 'Input.ReplyMode')])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.v1 = None
            self.neighbor = None
            self.virtual_circuit_id = None
            self.reply_mode = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2circuit-virtual-circuit/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2circuitVirtualCircuit.Input, ['v1', 'neighbor', 'virtual_circuit_id', 'reply_mode', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)

        class ReplyMode(Enum):
            """
            ReplyMode (Enum Class)

            Reply mode for ping request

            .. data:: no_reply = 0

            	Do not reply

            .. data:: ip_udp = 1

            	Reply via an IPv4 or IPv6 UDP packet

            .. data:: application_level_control_channel = 2

            	Reply via application level control channel

            """

            no_reply = Enum.YLeaf(0, "no-reply")

            ip_udp = Enum.YLeaf(1, "ip-udp")

            application_level_control_channel = Enum.YLeaf(2, "application-level-control-channel")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingL2circuitVirtualCircuit.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-l2circuit-virtual-circuit"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-l2circuit-virtual-circuit/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingL2circuitVirtualCircuit.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingL2circuitVirtualCircuit()
        return self._top_entity



class RequestPingLspEndPoint(Entity):
    """
    Ping end point of LSP
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingLspEndPoint.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingLspEndPoint.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingLspEndPoint, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-lsp-end-point"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingLspEndPoint.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingLspEndPoint.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-lsp-end-point"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: prefix
        
        	IP prefix/length of end point
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: instance
        
        	Routing\-instance name
        	**type**\: str
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: source
        
        	IP source address of echo request
        	**type**\: str
        
        .. attribute:: destination
        
        	IP address of destination for echo request
        	**type**\: str
        
        .. attribute:: exp
        
        	Forwarding class
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: size
        
        	Size of lsp ping request packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65468
        
        	**units**\: bytes
        
        .. attribute:: sweep
        
        	Incremental ping to find MTU
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingLspEndPoint.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-lsp-end-point"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('prefix', (YLeaf(YType.str, 'prefix'), ['str'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('source', (YLeaf(YType.str, 'source'), ['str'])),
                ('destination', (YLeaf(YType.str, 'destination'), ['str'])),
                ('exp', (YLeaf(YType.str, 'exp'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('sweep', (YLeaf(YType.empty, 'sweep'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.prefix = None
            self.instance = None
            self.count = None
            self.source = None
            self.destination = None
            self.exp = None
            self.detail = None
            self.size = None
            self.sweep = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-lsp-end-point/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingLspEndPoint.Input, ['prefix', 'instance', 'count', 'source', 'destination', 'exp', 'detail', 'size', 'sweep', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingLspEndPoint.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-lsp-end-point"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-lsp-end-point/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingLspEndPoint.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingLspEndPoint()
        return self._top_entity



class RequestPingVplsInstance(Entity):
    """
    Instance to which this VPLS connection belongs
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingVplsInstance.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingVplsInstance.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingVplsInstance, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-vpls-instance"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingVplsInstance.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingVplsInstance.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-vpls-instance"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: instance_name
        
        	Layer 2 VPLS name
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: destination_mac
        
        	Destination MAC address
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: source_ip
        
        	Source IP address
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: learning_vlan_id
        
        	Learning VLAN identifier
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..4094
        
        .. attribute:: control_plane_response
        
        	Request VPLS OAM responses using the control plane 
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: bd_name
        
        	Name of bridge domain
        	**type**\: str
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        .. attribute:: detail
        
        	Display detailed output
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingVplsInstance.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-vpls-instance"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('instance_name', (YLeaf(YType.str, 'instance-name'), ['str'])),
                ('destination_mac', (YLeaf(YType.str, 'destination-mac'), ['str'])),
                ('source_ip', (YLeaf(YType.str, 'source-ip'), ['str'])),
                ('learning_vlan_id', (YLeaf(YType.str, 'learning-vlan-id'), ['str','int'])),
                ('control_plane_response', (YLeaf(YType.empty, 'control-plane-response'), ['Empty'])),
                ('bd_name', (YLeaf(YType.str, 'bd-name'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('detail', (YLeaf(YType.empty, 'detail'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.instance_name = None
            self.destination_mac = None
            self.source_ip = None
            self.learning_vlan_id = None
            self.control_plane_response = None
            self.bd_name = None
            self.count = None
            self.detail = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-vpls-instance/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingVplsInstance.Input, ['instance_name', 'destination_mac', 'source_ip', 'learning_vlan_id', 'control_plane_response', 'bd_name', 'count', 'detail', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingVplsInstance.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-vpls-instance"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-vpls-instance/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingVplsInstance.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingVplsInstance()
        return self._top_entity



class RequestPingCeIp(Entity):
    """
    Ping CE IP address
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingCeIp.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingCeIp.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingCeIp, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-ce-ip"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingCeIp.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingCeIp.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-ce-ip"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: ip
        
        	IPv4 address of CE to be pinged
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: instance
        
        	VPLS or EVPN instance name
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: source_ip
        
        	Source IP address
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1000000
        
        	**units**\: packets
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingCeIp.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-ce-ip"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('ip', (YLeaf(YType.str, 'ip'), ['str'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('source_ip', (YLeaf(YType.str, 'source-ip'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
            ])
            self.ip = None
            self.instance = None
            self.source_ip = None
            self.count = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-ce-ip/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingCeIp.Input, ['ip', 'instance', 'source_ip', 'count'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: lsping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingCeIp.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-ce-ip"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('lsping_results', (YLeaf(YType.str, 'lsping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.lsping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-ce-ip/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingCeIp.Output, ['output', 'lsping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingCeIp()
        return self._top_entity



class RequestPingOverlay(Entity):
    """
    Ping overlay path
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingOverlay.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingOverlay.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingOverlay, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-overlay"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingOverlay.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingOverlay.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-overlay"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: tunnel_type
        
        	Tunnel type
        	**type**\:  :py:class:`TunnelType <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingOverlay.Input.TunnelType>`
        
        	**default value**\: vxlan
        
        .. attribute:: vni
        
        	Value of the vni that identifies the overlay segment
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..16777215
        
        	**mandatory**\: True
        
        .. attribute:: tunnel_src
        
        	Source VTEP IP address
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: tunnel_dst
        
        	Remote VTEP IP address
        	**type**\: str
        
        	**mandatory**\: True
        
        .. attribute:: mac
        
        	Validate MAC address
        	**type**\: str
        
        .. attribute:: count
        
        	Number of pings to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65535
        
        	**default value**\: 5
        
        .. attribute:: ttl
        
        	TTL to use in the ping packets
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        	**default value**\: 255
        
        .. attribute:: hash_input_interface
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        .. attribute:: hash_source_mac
        
        	
        	**type**\: str
        
        .. attribute:: hash_destination_mac
        
        	
        	**type**\: str
        
        .. attribute:: hash_protocol
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        .. attribute:: hash_source_address
        
        	
        	**type**\: str
        
        .. attribute:: hash_destination_address
        
        	
        	**type**\: str
        
        .. attribute:: hash_source_port
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65535
        
        .. attribute:: hash_destination_port
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65535
        
        .. attribute:: hash_vlan
        
        	
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..4094
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingOverlay.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-overlay"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('tunnel_type', (YLeaf(YType.enumeration, 'tunnel-type'), [('ydk.models.junos_qfx.junos_qfx_rpc_ping', 'RequestPingOverlay', 'Input.TunnelType')])),
                ('vni', (YLeaf(YType.str, 'vni'), ['str','int'])),
                ('tunnel_src', (YLeaf(YType.str, 'tunnel-src'), ['str'])),
                ('tunnel_dst', (YLeaf(YType.str, 'tunnel-dst'), ['str'])),
                ('mac', (YLeaf(YType.str, 'mac'), ['str'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('ttl', (YLeaf(YType.str, 'ttl'), ['str','int'])),
                ('hash_input_interface', (YLeaf(YType.str, 'hash-input-interface'), ['str','str'])),
                ('hash_source_mac', (YLeaf(YType.str, 'hash-source-mac'), ['str'])),
                ('hash_destination_mac', (YLeaf(YType.str, 'hash-destination-mac'), ['str'])),
                ('hash_protocol', (YLeaf(YType.str, 'hash-protocol'), ['str','int'])),
                ('hash_source_address', (YLeaf(YType.str, 'hash-source-address'), ['str'])),
                ('hash_destination_address', (YLeaf(YType.str, 'hash-destination-address'), ['str'])),
                ('hash_source_port', (YLeaf(YType.str, 'hash-source-port'), ['str','int'])),
                ('hash_destination_port', (YLeaf(YType.str, 'hash-destination-port'), ['str','int'])),
                ('hash_vlan', (YLeaf(YType.str, 'hash-vlan'), ['str','int'])),
            ])
            self.tunnel_type = None
            self.vni = None
            self.tunnel_src = None
            self.tunnel_dst = None
            self.mac = None
            self.count = None
            self.ttl = None
            self.hash_input_interface = None
            self.hash_source_mac = None
            self.hash_destination_mac = None
            self.hash_protocol = None
            self.hash_source_address = None
            self.hash_destination_address = None
            self.hash_source_port = None
            self.hash_destination_port = None
            self.hash_vlan = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-overlay/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingOverlay.Input, ['tunnel_type', 'vni', 'tunnel_src', 'tunnel_dst', 'mac', 'count', 'ttl', 'hash_input_interface', 'hash_source_mac', 'hash_destination_mac', 'hash_protocol', 'hash_source_address', 'hash_destination_address', 'hash_source_port', 'hash_destination_port', 'hash_vlan'], name, value)

        class TunnelType(Enum):
            """
            TunnelType (Enum Class)

            Tunnel type

            .. data:: vxlan = 0

            	Vxlan tunnel-type

            """

            vxlan = Enum.YLeaf(0, "vxlan")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: ping_overlay_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingOverlay.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-overlay"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('ping_overlay_results', (YLeaf(YType.str, 'ping-overlay-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.ping_overlay_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-overlay/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingOverlay.Output, ['output', 'ping_overlay_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingOverlay()
        return self._top_entity



class RequestPingEthernet(Entity):
    """
    Ping to an ethernet host by unicast mac address
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingEthernet.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_ping.RequestPingEthernet.Output>`
    
    

    """

    _prefix = 'ping'
    _revision = '2017-01-01'

    def __init__(self):
        super(RequestPingEthernet, self).__init__()
        self._top_entity = None

        self.yang_name = "request-ping-ethernet"
        self.yang_parent_name = "junos-qfx-rpc-ping"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = RequestPingEthernet.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = RequestPingEthernet.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-ping:request-ping-ethernet"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: wait
        
        	Delay after sending last packet
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..255
        
        	**units**\: seconds
        
        .. attribute:: size
        
        	Size of data TLV in request packets
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..1400
        
        	**units**\: bytes
        
        .. attribute:: count
        
        	Number of ping requests to send
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..65535
        
        .. attribute:: maintenance_domain
        
        	Name of maintenance domain
        	**type**\: str
        
        	**length:** 1..45
        
        	**mandatory**\: True
        
        .. attribute:: maintenance_association
        
        	Name of maintenance association
        	**type**\: str
        
        	**length:** 1..45
        
        	**mandatory**\: True
        
        .. attribute:: host
        
        	MAC address of remote host in xx\:xx\:xx\:xx\:xx\:xx format
        	**type**\: str
        
        .. attribute:: mep
        
        	MEP identifier of remote host (default 1)
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..8191
        
        .. attribute:: local_mep
        
        	MEP identifier of local host
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 1..8191
        
        .. attribute:: priority
        
        	Frame priority (802.1p) value
        	**type**\: union of the below types:
        
        		**type**\: str
        
        			**pattern:** <.\*>\|$.\*
        
        		**type**\: int
        
        			**range:** 0..7
        
        .. attribute:: rapid
        
        	Send requests rapidly 
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: logical_system
        
        	Name of logical system
        	**type**\: str
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingEthernet.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "request-ping-ethernet"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('wait', (YLeaf(YType.str, 'wait'), ['str','int'])),
                ('size', (YLeaf(YType.str, 'size'), ['str','int'])),
                ('count', (YLeaf(YType.str, 'count'), ['str','int'])),
                ('maintenance_domain', (YLeaf(YType.str, 'maintenance-domain'), ['str'])),
                ('maintenance_association', (YLeaf(YType.str, 'maintenance-association'), ['str'])),
                ('host', (YLeaf(YType.str, 'host'), ['str'])),
                ('mep', (YLeaf(YType.str, 'mep'), ['str','int'])),
                ('local_mep', (YLeaf(YType.str, 'local-mep'), ['str','int'])),
                ('priority', (YLeaf(YType.str, 'priority'), ['str','int'])),
                ('rapid', (YLeaf(YType.empty, 'rapid'), ['Empty'])),
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.wait = None
            self.size = None
            self.count = None
            self.maintenance_domain = None
            self.maintenance_association = None
            self.host = None
            self.mep = None
            self.local_mep = None
            self.priority = None
            self.rapid = None
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-ethernet/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingEthernet.Input, ['wait', 'size', 'count', 'maintenance_domain', 'maintenance_association', 'host', 'mep', 'local_mep', 'priority', 'rapid', 'logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: ethping_results
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'ping'
        _revision = '2017-01-01'

        def __init__(self):
            super(RequestPingEthernet.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "request-ping-ethernet"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('ethping_results', (YLeaf(YType.str, 'ethping-results'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.ethping_results = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-ping:request-ping-ethernet/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(RequestPingEthernet.Output, ['output', 'ethping_results', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = RequestPingEthernet()
        return self._top_entity



