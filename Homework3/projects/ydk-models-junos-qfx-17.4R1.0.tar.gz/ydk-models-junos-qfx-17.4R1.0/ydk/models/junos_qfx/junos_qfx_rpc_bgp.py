""" junos_qfx_rpc_bgp 

Junos RPC YANG module for bgp command(s)

"""
from collections import OrderedDict

from ydk.types import Entity, EntityPath, Identity, Enum, YType, YLeaf, YLeafList, YList, LeafDataList, Bits, Empty, Decimal64
from ydk.filters import YFilter
from ydk.errors import YError, YModelError
from ydk.errors.error_handler import handle_type_error as _handle_type_error




class GetBgpSummaryInformation(Entity):
    """
    Show overview of BGP information
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpSummaryInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpSummaryInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpSummaryInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-summary-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpSummaryInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpSummaryInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-summary-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: fabric
        
        	Internal fabric state
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: group
        
        	Show overview of bgp information for a particular group
        	**type**\: str
        
        .. attribute:: exact_instance
        
        	Show peer information for a particular instance
        	**type**\: str
        
        .. attribute:: instance
        
        	Show peer information for instances with this prefix
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpSummaryInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-summary-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('fabric', (YLeaf(YType.empty, 'fabric'), ['Empty'])),
                ('group', (YLeaf(YType.str, 'group'), ['str'])),
                ('exact_instance', (YLeaf(YType.str, 'exact-instance'), ['str'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
            ])
            self.logical_system = None
            self.fabric = None
            self.group = None
            self.exact_instance = None
            self.instance = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-summary-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpSummaryInformation.Input, ['logical_system', 'fabric', 'group', 'exact_instance', 'instance'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpSummaryInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-summary-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_information', (YLeaf(YType.str, 'bgp-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-summary-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpSummaryInformation.Output, ['output', 'bgp_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpSummaryInformation()
        return self._top_entity



class GetBgpReplicationInformation(Entity):
    """
    BGP NSR replication state between master and backup
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpReplicationInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpReplicationInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpReplicationInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-replication-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpReplicationInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpReplicationInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-replication-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpReplicationInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-replication-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
            ])
            self.logical_system = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-replication-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpReplicationInformation.Input, ['logical_system'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_sync_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpReplicationInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-replication-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_sync_information', (YLeaf(YType.str, 'bgp-sync-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_sync_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-replication-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpReplicationInformation.Output, ['output', 'bgp_sync_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpReplicationInformation()
        return self._top_entity



class GetBgpGroupInformation(Entity):
    """
    Show the BGP group database
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpGroupInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpGroupInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpGroupInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-group-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpGroupInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpGroupInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-group-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: verbosity_level
        
        	
        	**type**\:  :py:class:`VerbosityLevel <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpGroupInformation.Input.VerbosityLevel>`
        
        	**default value**\: brief
        
        .. attribute:: exact_instance
        
        	Show peer information for a particular instance
        	**type**\: str
        
        .. attribute:: instance
        
        	Show peer information for instances with this prefix
        	**type**\: str
        
        .. attribute:: group_name
        
        	Show group information for a particular group
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpGroupInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-group-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('verbosity_level', (YLeaf(YType.enumeration, 'verbosity_level'), [('ydk.models.junos_qfx.junos_qfx_rpc_bgp', 'GetBgpGroupInformation', 'Input.VerbosityLevel')])),
                ('exact_instance', (YLeaf(YType.str, 'exact-instance'), ['str'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('group_name', (YLeaf(YType.str, 'group-name'), ['str'])),
            ])
            self.logical_system = None
            self.verbosity_level = None
            self.exact_instance = None
            self.instance = None
            self.group_name = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-group-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpGroupInformation.Input, ['logical_system', 'verbosity_level', 'exact_instance', 'instance', 'group_name'], name, value)

        class VerbosityLevel(Enum):
            """
            VerbosityLevel (Enum Class)

            .. data:: summary = 0

            	Display summary output

            .. data:: brief = 1

            	Display brief output (default)

            .. data:: detail = 2

            	Display detailed output

            """

            summary = Enum.YLeaf(0, "summary")

            brief = Enum.YLeaf(1, "brief")

            detail = Enum.YLeaf(2, "detail")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_group_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpGroupInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-group-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_group_information', (YLeaf(YType.str, 'bgp-group-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_group_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-group-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpGroupInformation.Output, ['output', 'bgp_group_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpGroupInformation()
        return self._top_entity



class GetBgpRtfInformation(Entity):
    """
    Show route target filtering information
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpRtfInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpRtfInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpRtfInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-rtf-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpRtfInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpRtfInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-rtf-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: verbosity_level
        
        	
        	**type**\:  :py:class:`VerbosityLevel <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpRtfInformation.Input.VerbosityLevel>`
        
        	**default value**\: brief
        
        .. attribute:: group_name
        
        	Show group information for a particular group
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpRtfInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-rtf-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('verbosity_level', (YLeaf(YType.enumeration, 'verbosity_level'), [('ydk.models.junos_qfx.junos_qfx_rpc_bgp', 'GetBgpRtfInformation', 'Input.VerbosityLevel')])),
                ('group_name', (YLeaf(YType.str, 'group-name'), ['str'])),
            ])
            self.logical_system = None
            self.verbosity_level = None
            self.group_name = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-rtf-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpRtfInformation.Input, ['logical_system', 'verbosity_level', 'group_name'], name, value)

        class VerbosityLevel(Enum):
            """
            VerbosityLevel (Enum Class)

            .. data:: brief = 0

            	Display brief output (default)

            .. data:: detail = 1

            	Display detailed output

            """

            brief = Enum.YLeaf(0, "brief")

            detail = Enum.YLeaf(1, "detail")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_rtf_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpRtfInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-rtf-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_rtf_information', (YLeaf(YType.str, 'bgp-rtf-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_rtf_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-rtf-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpRtfInformation.Output, ['output', 'bgp_rtf_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpRtfInformation()
        return self._top_entity



class GetBgpTrafficStatisticsInformation(Entity):
    """
    Show packet statistics for labeled BGP routes
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpTrafficStatisticsInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpTrafficStatisticsInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpTrafficStatisticsInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-traffic-statistics-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpTrafficStatisticsInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpTrafficStatisticsInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-traffic-statistics-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: fabric
        
        	Internal fabric state
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: verbosity_level
        
        	
        	**type**\:  :py:class:`VerbosityLevel <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpTrafficStatisticsInformation.Input.VerbosityLevel>`
        
        	**default value**\: brief
        
        .. attribute:: group_name
        
        	Show group information for a particular group
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpTrafficStatisticsInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-traffic-statistics-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('fabric', (YLeaf(YType.empty, 'fabric'), ['Empty'])),
                ('verbosity_level', (YLeaf(YType.enumeration, 'verbosity_level'), [('ydk.models.junos_qfx.junos_qfx_rpc_bgp', 'GetBgpTrafficStatisticsInformation', 'Input.VerbosityLevel')])),
                ('group_name', (YLeaf(YType.str, 'group-name'), ['str'])),
            ])
            self.logical_system = None
            self.fabric = None
            self.verbosity_level = None
            self.group_name = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-traffic-statistics-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpTrafficStatisticsInformation.Input, ['logical_system', 'fabric', 'verbosity_level', 'group_name'], name, value)

        class VerbosityLevel(Enum):
            """
            VerbosityLevel (Enum Class)

            .. data:: brief = 0

            	Display brief output (default)

            .. data:: detail = 1

            	Display detailed output

            """

            brief = Enum.YLeaf(0, "brief")

            detail = Enum.YLeaf(1, "detail")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_traffic_statistics_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpTrafficStatisticsInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-traffic-statistics-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_traffic_statistics_information', (YLeaf(YType.str, 'bgp-traffic-statistics-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_traffic_statistics_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-traffic-statistics-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpTrafficStatisticsInformation.Output, ['output', 'bgp_traffic_statistics_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpTrafficStatisticsInformation()
        return self._top_entity



class GetBgpGroupOutputQueueInformation(Entity):
    """
    Show BGP output queues by priority
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpGroupOutputQueueInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpGroupOutputQueueInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpGroupOutputQueueInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-group-output-queue-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpGroupOutputQueueInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpGroupOutputQueueInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-group-output-queue-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: fabric
        
        	Internal fabric state
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: group_name
        
        	Show group information for a particular group
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpGroupOutputQueueInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-group-output-queue-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('fabric', (YLeaf(YType.empty, 'fabric'), ['Empty'])),
                ('group_name', (YLeaf(YType.str, 'group-name'), ['str'])),
            ])
            self.logical_system = None
            self.fabric = None
            self.group_name = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-group-output-queue-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpGroupOutputQueueInformation.Input, ['logical_system', 'fabric', 'group_name'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_group_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpGroupOutputQueueInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-group-output-queue-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_group_information', (YLeaf(YType.str, 'bgp-group-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_group_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-group-output-queue-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpGroupOutputQueueInformation.Output, ['output', 'bgp_group_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpGroupOutputQueueInformation()
        return self._top_entity



class GetBgpNeighborInformation(Entity):
    """
    Show the BGP neighbor database
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpNeighborInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpNeighborInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpNeighborInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-neighbor-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpNeighborInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpNeighborInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-neighbor-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: fabric
        
        	Internal fabric state
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: exact_instance
        
        	Show peer information for a particular instance
        	**type**\: str
        
        .. attribute:: instance
        
        	Show peer information for instances with this prefix
        	**type**\: str
        
        .. attribute:: neighbor_address
        
        	Show the neighbor database for a particular neighbor
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpNeighborInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-neighbor-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('fabric', (YLeaf(YType.empty, 'fabric'), ['Empty'])),
                ('exact_instance', (YLeaf(YType.str, 'exact-instance'), ['str'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('neighbor_address', (YLeaf(YType.str, 'neighbor-address'), ['str'])),
            ])
            self.logical_system = None
            self.fabric = None
            self.exact_instance = None
            self.instance = None
            self.neighbor_address = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-neighbor-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpNeighborInformation.Input, ['logical_system', 'fabric', 'exact_instance', 'instance', 'neighbor_address'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpNeighborInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-neighbor-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_information', (YLeaf(YType.str, 'bgp-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-neighbor-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpNeighborInformation.Output, ['output', 'bgp_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpNeighborInformation()
        return self._top_entity



class GetBgpOrfInformation(Entity):
    """
    Show outbound route filtering information
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpOrfInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpOrfInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpOrfInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-orf-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpOrfInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpOrfInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-orf-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: fabric
        
        	Internal fabric state
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: verbosity_level
        
        	
        	**type**\:  :py:class:`VerbosityLevel <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpOrfInformation.Input.VerbosityLevel>`
        
        	**default value**\: brief
        
        .. attribute:: instance
        
        	Show ORF information for instances with this prefix
        	**type**\: str
        
        .. attribute:: neighbor_address
        
        	Show ORF information for a particular neighbor
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpOrfInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-orf-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('fabric', (YLeaf(YType.empty, 'fabric'), ['Empty'])),
                ('verbosity_level', (YLeaf(YType.enumeration, 'verbosity_level'), [('ydk.models.junos_qfx.junos_qfx_rpc_bgp', 'GetBgpOrfInformation', 'Input.VerbosityLevel')])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('neighbor_address', (YLeaf(YType.str, 'neighbor-address'), ['str'])),
            ])
            self.logical_system = None
            self.fabric = None
            self.verbosity_level = None
            self.instance = None
            self.neighbor_address = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-orf-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpOrfInformation.Input, ['logical_system', 'fabric', 'verbosity_level', 'instance', 'neighbor_address'], name, value)

        class VerbosityLevel(Enum):
            """
            VerbosityLevel (Enum Class)

            .. data:: brief = 0

            	Display brief output (default)

            .. data:: detail = 1

            	Display detailed output

            """

            brief = Enum.YLeaf(0, "brief")

            detail = Enum.YLeaf(1, "detail")




    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_orf_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpOrfInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-orf-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_orf_information', (YLeaf(YType.str, 'bgp-orf-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_orf_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-orf-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpOrfInformation.Output, ['output', 'bgp_orf_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpOrfInformation()
        return self._top_entity



class GetBgpOutputQueueInformation(Entity):
    """
    Show outbound routes queue depths by priority
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpOutputQueueInformation.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpOutputQueueInformation.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpOutputQueueInformation, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-output-queue-information"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpOutputQueueInformation.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpOutputQueueInformation.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-output-queue-information"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: fabric
        
        	Internal fabric state
        	**type**\: :py:class:`Empty<ydk.types.Empty>`
        
        .. attribute:: instance
        
        	Show route queue depths for instances with this prefix
        	**type**\: str
        
        .. attribute:: neighbor_address
        
        	Show route queue depths for a particular neighbor
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpOutputQueueInformation.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-output-queue-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('fabric', (YLeaf(YType.empty, 'fabric'), ['Empty'])),
                ('instance', (YLeaf(YType.str, 'instance'), ['str'])),
                ('neighbor_address', (YLeaf(YType.str, 'neighbor-address'), ['str'])),
            ])
            self.logical_system = None
            self.fabric = None
            self.instance = None
            self.neighbor_address = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-output-queue-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpOutputQueueInformation.Input, ['logical_system', 'fabric', 'instance', 'neighbor_address'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpOutputQueueInformation.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-output-queue-information"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_information', (YLeaf(YType.str, 'bgp-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-output-queue-information/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpOutputQueueInformation.Output, ['output', 'bgp_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpOutputQueueInformation()
        return self._top_entity



class GetBgpMonitoringProtocolStatistics(Entity):
    """
    Show BGP Monitoring Protocol information
    
    .. attribute:: input
    
    	
    	**type**\:  :py:class:`Input <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpMonitoringProtocolStatistics.Input>`
    
    .. attribute:: output
    
    	
    	**type**\:  :py:class:`Output <ydk.models.junos_qfx.junos_qfx_rpc_bgp.GetBgpMonitoringProtocolStatistics.Output>`
    
    

    """

    _prefix = 'bgp'
    _revision = '2017-01-01'

    def __init__(self):
        super(GetBgpMonitoringProtocolStatistics, self).__init__()
        self._top_entity = None

        self.yang_name = "get-bgp-monitoring-protocol-statistics"
        self.yang_parent_name = "junos-qfx-rpc-bgp"
        self.is_top_level_class = True
        self.has_list_ancestor = False
        self.ylist_key_names = []
        self._child_classes = OrderedDict([])
        self._leafs = OrderedDict()

        self.input = GetBgpMonitoringProtocolStatistics.Input()
        self.input.parent = self
        self._children_name_map["input"] = "input"

        self.output = GetBgpMonitoringProtocolStatistics.Output()
        self.output.parent = self
        self._children_name_map["output"] = "output"
        self._segment_path = lambda: "junos-qfx-rpc-bgp:get-bgp-monitoring-protocol-statistics"
        self._is_frozen = True


    class Input(Entity):
        """
        
        
        .. attribute:: logical_system
        
        	Name of logical system, or 'all'
        	**type**\: str
        
        .. attribute:: station_name
        
        	Show information for a particular station
        	**type**\: str
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpMonitoringProtocolStatistics.Input, self).__init__()

            self.yang_name = "input"
            self.yang_parent_name = "get-bgp-monitoring-protocol-statistics"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('logical_system', (YLeaf(YType.str, 'logical-system'), ['str'])),
                ('station_name', (YLeaf(YType.str, 'station-name'), ['str'])),
            ])
            self.logical_system = None
            self.station_name = None
            self._segment_path = lambda: "input"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-monitoring-protocol-statistics/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpMonitoringProtocolStatistics.Input, ['logical_system', 'station_name'], name, value)



    class Output(Entity):
        """
        
        
        .. attribute:: output
        
        	
        	**type**\: str
        
        .. attribute:: bgp_information
        
        	
        	**type**\: anyxml
        
        .. attribute:: multi_routing_engine_results
        
        	
        	**type**\: anyxml
        
        

        """

        _prefix = 'bgp'
        _revision = '2017-01-01'

        def __init__(self):
            super(GetBgpMonitoringProtocolStatistics.Output, self).__init__()

            self.yang_name = "output"
            self.yang_parent_name = "get-bgp-monitoring-protocol-statistics"
            self.is_top_level_class = False
            self.has_list_ancestor = False
            self.ylist_key_names = []
            self._child_classes = OrderedDict([])
            self._leafs = OrderedDict([
                ('output', (YLeaf(YType.str, 'output'), ['str'])),
                ('bgp_information', (YLeaf(YType.str, 'bgp-information'), ['str'])),
                ('multi_routing_engine_results', (YLeaf(YType.str, 'multi-routing-engine-results'), ['str'])),
            ])
            self.output = None
            self.bgp_information = None
            self.multi_routing_engine_results = None
            self._segment_path = lambda: "output"
            self._absolute_path = lambda: "junos-qfx-rpc-bgp:get-bgp-monitoring-protocol-statistics/%s" % self._segment_path()
            self._is_frozen = True

        def __setattr__(self, name, value):
            self._perform_setattr(GetBgpMonitoringProtocolStatistics.Output, ['output', 'bgp_information', 'multi_routing_engine_results'], name, value)


    def clone_ptr(self):
        self._top_entity = GetBgpMonitoringProtocolStatistics()
        return self._top_entity



