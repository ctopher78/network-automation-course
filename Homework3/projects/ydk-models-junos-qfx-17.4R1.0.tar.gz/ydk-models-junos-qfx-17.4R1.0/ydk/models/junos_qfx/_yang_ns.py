BUNDLE_NAME = "junos_qfx"

CAPABILITIES = {
    "junos-common-ddl-extensions": "2017-01-01",
    "junos-common-odl-extensions": "2017-01-01",
    "junos-common-types": "2017-01-01",
    "junos-qfx-conf-access": "2017-01-01",
    "junos-qfx-conf-interfaces": "2017-01-01",
    "junos-qfx-conf-policy-options": "2017-01-01",
    "junos-qfx-conf-protocols": "2017-01-01",
    "junos-qfx-conf-root": "2017-01-01",
    "junos-qfx-conf-routing-options": "2017-01-01",
    "junos-qfx-conf-system": "2017-01-01",
    "junos-qfx-rpc-bgp": "2017-01-01",
    "junos-qfx-rpc-cli": "2017-01-01",
    "junos-qfx-rpc-ping": "2017-01-01",
    "junos-qfx-rpc-traceroute": "2017-01-01",
}

ENTITY_LOOKUP = {
    ("http://yang.juniper.net/junos-qfx/conf/root", "configuration"): "junos_qfx_conf_root.Configuration",
    ("junos-qfx-conf-root", "configuration"): "junos_qfx_conf_root.Configuration",
}

NAMESPACE_LOOKUP = {
    "junos-common-ddl-extensions": "http://yang.juniper.net/junos/common/ddl-extensions",
    "junos-common-odl-extensions": "http://yang.juniper.net/junos/common/odl-extensions",
    "junos-common-types": "http://yang.juniper.net/junos/common/types",
    "junos-qfx-conf-access": "http://yang.juniper.net/junos-qfx/conf/access",
    "junos-qfx-conf-interfaces": "http://yang.juniper.net/junos-qfx/conf/interfaces",
    "junos-qfx-conf-policy-options": "http://yang.juniper.net/junos-qfx/conf/policy-options",
    "junos-qfx-conf-protocols": "http://yang.juniper.net/junos-qfx/conf/protocols",
    "junos-qfx-conf-root": "http://yang.juniper.net/junos-qfx/conf/root",
    "junos-qfx-conf-routing-options": "http://yang.juniper.net/junos-qfx/conf/routing-options",
    "junos-qfx-conf-system": "http://yang.juniper.net/junos-qfx/conf/system",
    "junos-qfx-rpc-bgp": "http://yang.juniper.net/junos-qfx/rpc/bgp",
    "junos-qfx-rpc-cli": "http://yang.juniper.net/junos-qfx/rpc/cli",
    "junos-qfx-rpc-ping": "http://yang.juniper.net/junos-qfx/rpc/ping",
    "junos-qfx-rpc-traceroute": "http://yang.juniper.net/junos-qfx/rpc/traceroute",
}

IDENTITY_LOOKUP = {
}

